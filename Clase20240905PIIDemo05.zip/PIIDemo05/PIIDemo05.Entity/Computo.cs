﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIIDemo05.Entity
{
    public class Computo
    {
        public int ComputoId { get; set; }
        public string Nombre { get; set; }
    }
}
