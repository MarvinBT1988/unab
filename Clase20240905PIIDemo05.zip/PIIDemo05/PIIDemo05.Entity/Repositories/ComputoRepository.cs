﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIIDemo05.Entity.Repositories
{
    public class ComputoRepository
    {
        private List<Computo> _computos;
        public ComputoRepository() {
            _computos = new List<Computo>()
            {
              new Computo() { ComputoId=1, Nombre="CC1" },
              new Computo() { ComputoId = 2, Nombre = "CC2" },
              new Computo() { ComputoId = 3, Nombre = "CC3" },
              new Computo() { ComputoId = 4, Nombre = "Electrica" }
            };
        }
        public List<Computo> Computos{
            get{
              return _computos;
            }
        }
    }
}
