﻿using System;
using System.Windows.Forms;
using PIIDemo05.Entity.Repositories;

namespace PIIDemo05.PIIDemos05View
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            UpdateCombo();
        }
        private void UpdateCombo() {
            ComputoRepository computoRepository = new ComputoRepository();
            cbComputos.DisplayMember = "Nombre";
            cbComputos.ValueMember = "ComputoId";
            cbComputos.DataSource = computoRepository.Computos;
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
